export const PRIORITIES = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high'
};

export const TASK_STATUS = {
  PENDING: 'pending',
  COMPLETED: 'completed'
};